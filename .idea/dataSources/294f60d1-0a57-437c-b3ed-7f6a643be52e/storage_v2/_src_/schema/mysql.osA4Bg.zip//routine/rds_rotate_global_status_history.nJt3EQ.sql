create
    definer = rdsadmin@localhost procedure rds_rotate_global_status_history()
BEGIN
     DECLARE sql_logging BOOLEAN;
     select @@sql_log_bin into sql_logging;
     set @@sql_log_bin=off;
     drop table mysql.rds_global_status_history_old;
     rename table mysql.rds_global_status_history to mysql.rds_global_status_history_old;
     create table mysql.rds_global_status_history like mysql.rds_global_status_history_old;
     set @@sql_log_bin=sql_logging;
END;

