create view ps_check_lost_instrumentation as
select `information_schema`.`global_status`.`VARIABLE_NAME`  AS `variable_name`,
       `information_schema`.`global_status`.`VARIABLE_VALUE` AS `variable_value`
from `information_schema`.`global_status`
where ((`information_schema`.`global_status`.`VARIABLE_NAME` like 'perf%lost') and
       (`information_schema`.`global_status`.`VARIABLE_VALUE` > 0));

